export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-center p-4">
      <h1 className="text-2xl font-bold">Smart Care MVP 問卷即將在此顯示</h1>
    </main>
  );
}
