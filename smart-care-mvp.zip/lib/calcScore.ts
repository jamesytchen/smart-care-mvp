// TODO: Implement scoring logic based on answers
export function calcScore(data: Record<string, any>) {
  return { level: 1, bundle: "示範建議" };
}
